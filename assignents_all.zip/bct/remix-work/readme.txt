This is a Remix backup file.
This zip should be used by the restore backup tool in Remix.
The .workspaces directory contains your workspaces.



// it contains 

assgn-3		|     bank transcations
assgn-4     	|     student data
mini project	|     e-voting systems